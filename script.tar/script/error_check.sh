#!/bin/bash

if [ "$1" = "0" ]; then
	echo
	echo "---< $2 is OK >-----------------------------------------------"
	echo
else
	echo
	echo "!! $2 is Failed !!"
	echo
	exit $1
fi

