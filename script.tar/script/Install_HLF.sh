#!/bin/bash
echo "---< Install Hyperledger Fabric Start >---------------------------"
sudo apt update -y && \
curl -sSL https://bit.ly/2ysbOFE | bash -s -- $HLF_version $HLF_CA_version
error_code=$?
./error_check.sh "$error_code" "Install_HLF.sh: Install Hyperledger Fabric"

