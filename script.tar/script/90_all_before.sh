#!/bin/bash

source ./00_Setting_version_info.sh && \
#./Install_tools.sh && \
#./Install_docker.sh && \
#./Install_Nodejs_npm.sh && \
./Install_Go.sh && \
./Output_message_to_reLogin.sh


./error_check.sh "$?" "90_all_before.sh"
