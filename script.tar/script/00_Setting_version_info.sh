#!/bin/bash
echo "---< Setting Environment Values >--------------------------"

#Don't use ""
# ok yes or no : x "yes" or "no"

#-<proxy>------------------------------------------------------------------
#Are your Environment in Proxy ?
#Please setting proxy "yes" or "no"
export proxy=no

#-<Fabric and CA version>------------------------------------------------------------------
#What version do you want to install Hyperledger fablic and CA ?
#Please setting HLF_version and HLF CA version .

#For example ,
#HLF_version=2.4.0
#HLF_CA_version=1.5.2

#If you want to install latest
#HLF_version=
#HLF_CA_version=
#or
#HLF_version=latest
#HLF_CA_version=latest

export HLF_version=2.2.4
export HLF_CA_version=1.5.2


#-<Docker and Docker compose version>---------------------------------------------------------------------------
#What version do you want to install Docker and Docker compose ?
#Please setting Docker_version and Docker_compose_version .
#!! Sorry: Now we can install docker only latest !!

#Docker_version=
#Docker_compose_version=


#-<Go version>--------------------------------------------------------------------------------
#What version do you want to install Go ?
#Please setting Go_version .
export Go_version=1.16.7


#-<Node.js and npm version>-------------------------------------------------------------------
#What version do you want to install Node.js and npm ?
#Please setting Node_version and npm_version .
export Node_version=12.16.1
export npm_version=6.4.1


#Error code
error_code=$?
echo "< Version infomation >"
echo "Proxy		: $proxy"
echo "Fabric		: $HLF_version"
echo "Fabric CA	: $HLF_CA_version"
echo "Docker		: stable"
echo "Docker Compose	: stable"
echo "Go		: $Go_version"
echo "Node.js		: $Node_version"
echo "npm		: $npm_version"
echo

./error_check.sh "$error_code" "00_Setthing_version_info.sh"  
#exit $error_code
