#!/bin/bash
echo "---< Install Curl, Git, JQ,  >--------------------------"
sudo apt update -y 
error_code=$?
source ./error_check.sh "$error_code" "Install_tools.sh: apt update"

sudo apt upgrade -y
error_code=$?
source ./error_check.sh "$error_code" "Install_tools.sh: apt upgrade"

sudo apt install git -y
error_code=$?
source ./error_check.sh "$error_code" "Install_tools.sh: Install git"

sudo apt install curl -y
error_code=$?
source ./error_check.sh "$error_code" "Install_tools.sh: Install curl"

sudo apt install ca-certificates -y
error_code=$?
source ./error_check.sh "$error_code" "Install_tools.sh: Install ca-certificates"

sudo apt install gnupg -y
error_code=$?
source ./error_check.sh "$error_code" "Install_tools.sh: Install gnupg"

sudo apt install lsb-release
error_code=$?
source ./error_check.sh "$error_code" "Install_tools.sh: Install lsb-release"

sudo apt install apt-transport-https
error_code=$?
source ./error_check.sh "$error_code" "Install_tools.sh: apt-transport-https"

sudo apt install gnupg-agent
error_code=$?
source ./error_check.sh "$error_code" "Install_tools.sh: Install gnupg-agent"

sudo apt install software-properties-common
error_code=$?
source ./error_check.sh "$error_code" "Install_tools.sh: Install software-properties-common"


error_code=$?
source ./error_check.sh "$error_code" "Install_tools.sh"
echo
