#!/bin/bash
echo "---< Install docker and docker-compose Start >---------------------------"
sudo apt remove docker docker-engine docker.io containerd runc
sudo apt update -y && \
sudo apt install -y docker.io docker-compose
error_code=$?
source ./error_check.sh "$error_code" "Install_docker.sh: Install"

sudo gpasswd -a ${USER} docker && \
sudo systemctl restart docker.service
error_code=$?
source ./error_check.sh "$error_code" "Install_docker.sh: Setting docker groups"

sudo chmod +x /usr/bin/docker-compose
error_code=$?
source ./error_check.sh "$error_code" "Install_docker.sh: chmod +x docker-compose"
echo

