#!/bin/bash

echo "---< Install Node.js, npm and n Start >---------------------------"
#sudo apt remove 
sudo apt update -y && \
sudo apt install -y npm && \
sudo apt install -y nodejs
error_code=$?
source ./error_check.sh "$error_code" "Install_Nodejs_npm.sh: Node.js and npm Install"

sudo npm install -g n
error_code=$?
source ./error_check.sh "$error_code" "Install_Nodejs_npm.sh: Install n install"
echo $Node_version
sudo n $Node_version
error_code=$?
source ./error_check.sh "$error_code" "Install_Nodejs_npm.sh: Change Node version"

sudo npm install -g npm@$npm_version
error_code=$?
source ./error_check.sh "$error_code" "Install_Nodejs_npm.sh: Change npm version"

echo -n "node :"
node -v
echo -n "npm :"
npm -v

echo

