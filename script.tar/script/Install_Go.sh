#!/bin/bash

echo "---< Install Node.js, npm and n Start >---------------------------"
#sudo apt remove 
sudo apt update -y && \
wget https://dl.google.com/go/go${Go_version}.linux-amd64.tar.gz
error_code=$?
source ./error_check.sh "$error_code" "Install_Go.sh: Download Go"

sudo tar -C /usr/local -xzf go${Go_version}.linux-amd64.tar.gz
error_code=$?
source ./error_check.sh "$error_code" "Install_Go.sh: Untar Go"

echo "export PATH=\$PATH:/usr/local/go/bin" | sudo tee -a /etc/profile
error_code=$?
source ./error_check.sh "$error_code" "Install_Go.sh: Update /etc/profile"
echo

