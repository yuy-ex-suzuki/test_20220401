#!/bin/bash
echo "---< Update packages and disable auto update  >--------------------------"

sudo apt update -y && sudo apt upgrade -y
error_code=$?
if [ "$error_code" = "0" ]; then
	echo
else
	echo
	echo "!! Failed the command apt update or upgrade. Please check network or else !!"
fi
echo
exit "$error_code"
