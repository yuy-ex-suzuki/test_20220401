#!/bin/bash
echo "-------------------------------------------------------------------------"
echo
echo "Please Re Login to complete setting docker"
echo 'After Re Login, please try to command "./Check_install_result.sh" '
echo
apt moo
echo
echo "-------------------------------------------------------------------------"

exit $exit_code
